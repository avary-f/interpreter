#include <vector>
#include <string>
using namespace std;
#pragma once
#include "Relation.h"
#include "Tuple.h"
#include <map> // needed to include set class
#include <iostream>

class Database {

private:
    string name;
    map<string, Relation> relations;

public:
    Database(const string name, const map<string, Relation> relations) : name(name), relations(relations) {}
    Database(){}

void addRelation(string name, const Relation& relation) {
    relations.emplace(name, relation);
}
void addTupletoRelation(string key, const Tuple& tuple) {
    auto it = relations.find(key);
    if (it != relations.end()) {
        it->second.addTuple(tuple);
    }
}

set<Tuple> getRelationTuples(string key){
    auto it = relations.find(key);
    return it->second.getTuples();
    // if (it != relations.end()) {
    //     return it->second;
    // }
    // return;
}


string toString() const {
    string str;
    if (relations.empty()) {
        return "";
    }
    for (auto current = relations.begin(); current != relations.end(); ++current) {
        str = str + current->first + ": " + current->second.toString() + "\n";
    }
    return str;
}

};