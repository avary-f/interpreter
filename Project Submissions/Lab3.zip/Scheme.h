#include <vector>
#include <string>
using namespace std;
#pragma once

class Scheme { //delegation 

private: 

  vector<string> names;

public:

  Scheme(vector<string> names) : names(names) { }

  unsigned size() const {
    return names.size();
  }

  const string& at(int index) const {
    return names.at(index);
  }

  // TODO: add more delegation functions as needed

};

//option for using inheritance of the string vecotr functions instead...
// class Scheme : public vector<string> {

//  public:

//   Scheme(vector<string> names) : vector<string>(names) { }

// };