#include <vector>
#include <string>
using namespace std;
#pragma once
#include "Scheme.h"
#include "Tuple.h"
#include <set> // needed to include set class
#include <iostream>

class Relation {

private:
    string name;
    Scheme scheme;
    set<Tuple> tuples;

public:
    Relation(const string name, const Scheme& scheme) : name(name), scheme(scheme) {} //constructor

void addTuple(const Tuple& tuple) {
    tuples.insert(tuple); //use insert to add to a set
}

string toString() const {
    string str;
    if(tuples.empty()){
        return "";
    }
    auto current = tuples.begin(); //will be an iterator pointing to the first element of touples set
    str = current->toString(scheme); //the -> is used to dereference the current object
    for(; current != tuples.end(); ++current){ //pretty much a while loop
        str = str + "\n";
        current++;
        str = str + current->toString(scheme);
    }
    return str;
}

Relation select(int index, const string& value) const {
    Relation rel(name, scheme);
    auto current = tuples.begin();
    for(int i = 0; i < tuples.size(); i++){
        if(current->at(index) == value){
            rel.addTuple(*current);
        }
        current++;
    }
    return rel;
}

};
