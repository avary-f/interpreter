#include <vector>
#include <string>
using namespace std;
#pragma once

#include "Scheme.h"

class Tuple {

private:

  vector<string> values;

public:

  Tuple(vector<string> values) : values(values) { }

  unsigned size() const {
    return values.size();
  }

  const string& at(int index) const {
    return values.at(index);
  }

  vector<string> getValues() const {
    return values;
  }

  bool operator<(const Tuple t) const {
    return values < t.values;
  }

  // string toString() {
  //   cout << "size: " << values.size() << endl;
  //   for (int i = 0; i  < values.size(); i++) {
  //     cout << i << " " << values.at(i) << endl;
  //   }
  //   cout << "end" << endl;
  // }

  string toString(const Scheme& s) const {
    string str;
    const Tuple& tuple = *this;
    
    // Check if the tuple and scheme have the same size
    /*if (tuple.size() != s.size()) {
        cout << "tup szie "<< endl;
        return ""; // Return an empty string if they don't match
    }*/
    
    if (s.size() == 0) {
        return "";
        //cout << "s is empty" << endl;
    }

    str = s.at(0) + "=" + tuple.at(0);

    for (int i = 1; i < s.size(); i++) {
        str += " , ";
        
        // Check if the index is within the bounds of the tuple
        if (i < tuple.size()) {
            str += s.at(i) + "=" + tuple.at(i);
        } else {
            //str += s.at(i) + "=" + "OUT_OF_BOUNDS"; // Indicate out-of-bounds access
        }
    }
    return str;
}


};

//you can also just inheirit from the string class instead