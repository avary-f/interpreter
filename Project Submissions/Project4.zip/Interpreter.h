#include <vector>
#include <string>
using namespace std;
#pragma once
#include "Database.h"
#include "Relation.h"
#include "DatalogProgram.h"
#include <iostream>
#include <unordered_map>
#include <cctype>
#include <unordered_set>

class Interpreter {

private:
    Database database;
    DatalogProgram program;

public:
    Interpreter(const DatalogProgram& program) : program(program) {}

void evalSchemes(){
    for(int i = 0; i < program.getSchemes().size(); i++){
        string name = program.getSchemes().at(i).getID();
        vector<string> attributes = program.getSchemes().at(i).getParameters();
        database.addRelation(name, Relation(name, attributes));
    }
}

void evalFacts(){
    for(int i = 0; i < program.getFacts().size(); i++){
        string name = program.getFacts().at(i).getID();
        vector<string> values = program.getFacts().at(i).getParameters();
        database.addTupletoRelation(name, Tuple(values));
    }
}

void evalQueries() {
    cout << "Query Evaluation" << endl;
    for (int i = 0; i < program.getQueries().size(); i++) { //query
        string name = program.getQueries().at(i).getID();
        Relation relation = Relation(name, database.getRelationTuples(name));
        map<string, int> variables;
        vector<string> orderOfAppearance;  // Keep track of the order of appearance
        //cout << "a" << endl;
        for (int j = 0; j < program.getQueries().at(i).getParameters().size(); j++) { //param
            string param_name = program.getQueries().at(i).getParameters().at(j);

            if (param_name[0] == '\'') {
                relation = relation.select(j, param_name);
            } else {
                auto var = variables.find(param_name);
                if (var == variables.end()) {
                    variables[param_name] = j;
                    orderOfAppearance.push_back(param_name);  // Record the order
                } else {
                    relation = relation.select2(var->second, j);
                }
            }
        }
        //cout << "b" << endl;
        vector<int> indexes;  // Indexes of variables
        for (const auto& variable : orderOfAppearance) {
            indexes.push_back(variables[variable]);
        }

        // Testing
        // cout << "Variables order of appearance: ";
        // for (const auto& element : orderOfAppearance) {
        //     cout << element << " ";
        // }
        // cout << endl;

        // Project and rename
        relation = relation.project(indexes);
        relation = relation.rename(orderOfAppearance);
        //cout << "c" << endl;
        string result;
        if (relation.sizeTuples() != 0) {
            result = "Yes(" + to_string(relation.sizeTuples()) + ")";
        } else {
            result = "No";
        }
        //cout << "d" << endl;
        cout << program.getQueries().at(i).toString() << "? ";
        cout << result << endl;

        if (variables.size() != 0) {
            cout << relation.toString();
        }
    }
}

bool areEqualIgnoreCase(const std::string& str1, const std::string& str2) {
    // If lengths are different, strings are not equal
    if (str1.length() != str2.length()) {
        return false;
    }
    
    // Convert both strings to the same case (e.g., upper case)
    std::string upperStr1, upperStr2;
    for (char c : str1) {
        upperStr1 += std::toupper(c);
    }
    for (char c : str2) {
        upperStr2 += std::toupper(c);
    }
    
    // Compare the modified strings
    return upperStr1 == upperStr2;
}


void evalRules() {
    bool changed = true; // Initialize to true to enter the loop
    int count = 0;
    cout << "Rule Evaluation" << endl;
    while (changed) { // Loop until there are no more changes
        count++;
        int initial = database.getSizeofTuples();
        for (int i = 0; i < program.getRules().size(); i++) { //for each rule
            Rule current_rule = program.getRules().at(i);
            cout << current_rule.toString() << endl;

            string head_rule = current_rule.getHead().getID();
            vector<Relation> relations_list;

            // Pred
            for (int j = 0; j < current_rule.getBody().size(); j++) { // for each pred in body
                // Retrieve relation
                string body_name = current_rule.getBody().at(j).getID();
                Relation relation_old = database.getRelation(body_name);
                //cout << relation_old.toString() << endl;

                // Check if relation is empty
                if (relation_old.getTuples().empty()) {
                    // Skip further processing for this rule
                    //cout << "Empty relation for predicate: " << body_name << endl;
                    relations_list.clear(); // Clear any previously collected relations
                    //break; // Move on to the next rule
                }

                // Process relation and collect in relations_list
                // ...
                map<string, int> variables;
                vector<string> orderOfAppearance;

                // Params
                for (int k = 0; k < current_rule.getBody().at(j).getParameters().size(); k++) { //for each param in pred
                    string param_name = current_rule.getBody().at(j).getParameters().at(k); // parameter name
                    if (param_name[0] == '\'') {
                        relation_old = relation_old.select(k, param_name);
                    } else { //variable
                        auto var = variables.find(param_name);
                        if (var == variables.end()) {
                            variables[param_name] = k;
                            orderOfAppearance.push_back(param_name);  // Record the order
                        } else {
                            relation_old = relation_old.select2(var->second, k);
                        }
                    }
                }

                // Project
                vector<int> indexes;
                for (string variable : orderOfAppearance) {
                    indexes.push_back(variables[variable]);
                }
                // cout << "first project before" << endl;
                // cout << relation_old.toString() << endl;
                relation_old = relation_old.project(indexes);
                // cout << "first project after" << endl;
                // cout << relation_old.toString() << endl;
                
                relation_old = relation_old.rename(orderOfAppearance);
                // cout << "first rename after" << endl;
                // cout << relation_old.toString() << endl;
                //right here cout << relation_old.toString() << endl;
                relations_list.push_back(relation_old);
            }

            if (relations_list.empty()) {
                // Skip further processing for this rule
                // cout << "No tuples found for any predicate in the rule." << endl;
                continue; // Move on to the next rule
            }

            // Join
            Relation relation_new = relations_list.at(0);
            for (int index = 1; index < relations_list.size(); index++) {
                // cout << index << " " << relation_new.toString() << endl;
                // cout << index << " " << relations_list.at(index).toString() << endl;
                relation_new = relation_new.join(relations_list.at(index));
                //cout << index << " " << relation_new.toString() << endl;
                
            }

            // Get Indexes
            vector<int> indexes;
            // cout << current_rule.getHead().getParameters().size() << " ";
            // cout << relation_new.getScheme().size() << endl;
            // cout << "before get indexes" << endl;
            //wong here cout << relation_new.toString() << endl;
            for(int n = 0; n < current_rule.getHead().getParameters().size(); n++){ //for each param n in head
                for(int m = 0; m < relation_new.getScheme().size(); m++){ // for each param in current scheme
                    //convert to lower
                    //cout << relation_new.getScheme().at(m) << endl;
                    string s = relation_new.getScheme().at(m);
                    // string str;
                    // for(char c: s){
                    //     str += tolower(c);
                    // }
                    //cout << s << endl;
                    //if equal
                    if(areEqualIgnoreCase(current_rule.getHead().getParameters().at(n), s)){   
                        indexes.push_back(m); //add index of current scheme
                        //cout << "m: " << m << endl;
                    }
                }
            }
            // for(int index : indexes){
            //     cout << index << " ";
            // }

            // Project
            //cout << "before project" << endl;
            // wrong here cout << relation_new.toString();

            relation_new = relation_new.project(indexes);
            // cout << "after project" << endl;
            // wrong here cout << relation_new.toString();
            //relation_new = relation_new.rename(relation_new.getScheme());
            //cout << "after rename" << endl;
            // wrong here-> cout << relation_new.toString();

            // Set the name and scheme of the new relation
            relation_new.setName(head_rule);
            // for(string index: current_rule.getHead().getParameters()){
            //     cout << index << " ";
            // }
            relation_new.setScheme(current_rule.getHead().getParameters());

            // Union with database and check for changes
            // if(relation_new.getTuples().size() == 0){
            //     cout << "empty" << endl;
            // }
            // for(string  index: relation_new.getScheme()){
            //     cout << index << " ";
            // }
            
            // cout << "scheme size" << relation_new.getScheme().size();
            // //IT CANT PRINT THIS!!!!
            // for(Tuple index: relation_new.getTuples()){
            //     cout << index.toString() << " ";
            // }
            // cout << "scheme size" << relation_new.getScheme().size();

            // cout << endl;
            // cout << "after for" << endl;
            database.union_relation(relation_new);
            
            
            // relation_new = result.second;
            // if(relation_new.getTuples().size() == 0){
            //     cout << "empty2" << endl;
            // }
            
            // cout << relation_new.toString();
            //changed = false;

            //changed = database.union_relation(relation_new);
            // cout << "test before" << endl;
            //cout << changed << endl;
            // cout << relation_new.toString() << endl;
            // if(relation_new.toString() != "" && changed == true){
            //     //cout << current_rule.toString() << endl;
            //     //cout << relation_new.toString();
            // } 
            //cout << "test" << endl;

        }
       if(database.getSizeofTuples() == initial){
            changed = false;
       }
       else{
            changed = true;
       }
    }


    //Output - Moved outside the loop
    // for(auto element: program.getRules()){
    //     cout << element.toString() << endl;
    // }
    cout << endl;
    cout << "Schemes populated after " << count << " passes through the Rules." << endl;
    cout << endl;
}



};