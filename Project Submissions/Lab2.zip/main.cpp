// Project: 1
// Date: 1/29/24
// main.cpp

#include <iostream>
#include <vector>
#include <fstream>

#include <string>
#include "Token.h" //needed to access the token class
#include "Scanner.h"
#include "Parser.h"

using namespace std;

int main() {

  vector<Token> tokens = {
    Token(ID,"Ned",2),
    //Token(LEFT_PAREN,"(",2),
    Token(ID,"Ted",2),
    Token(COMMA,",",2),
    Token(ID,"Zed",2),
    Token(RIGHT_PAREN,")",2),
  };

  Parser p = Parser(tokens);
  p.scheme();

}