// Project: 1
// Date: 1/29/24
// main.cpp

#include <iostream>
#include <vector>
#include <fstream>

#include <string>
#include "Token.h" //needed to access the token class
#include "Scanner.h"
#include "Parser.h"
#include "Scheme.h"
#include "Tuple.h"
#include "Relation.h"
//#include "Interpreter.h"

using namespace std;


// //int main() {
// int main(int argc, char* argv[]) {
//   ifstream inputFile(argv[1]); // Open file for reading
//   //ifstream inputFile("text.txt"); // Testing

//   if (!inputFile.is_open()) { // Check if file is open
//       cerr << "Error opening the file" << endl;
//       return 1; // Return an error code
//   }

//   string line;
//   stringstream ss;
//   while (getline(inputFile, line)) {
//       ss << line << '\n';
//   }
//   string full_input = ss.str();

//   inputFile.close(); // Close file

//   Scanner s = Scanner(full_input);
//   vector<Token> tokens = s.scanToken();
//   //cout << "Size of tokens: " << tokens.size() << endl;
//   Parser parser = Parser(tokens);
//   parser.parse();

//   // for (int i = 0; i < tokens.size(); i++) {
//   //     cout << tokens[i].toString() << endl;
//   // }
//   // cout << "Total Tokens = " << tokens.size() << endl;

//   return 0;
// }


int main() {

  Relation studentRelation("students", Scheme( {"ID", "Name", "Major"} ));

  vector<string> studentValues[] = {
    {"'42'", "'Ann'", "'CS'"},
    {"'64'", "'Ned'", "'EE'"},
  };

  for (auto& value : studentValues)
    studentRelation.addTuple(Tuple(value));

  studentRelation.join(studentRelation);

  cout << endl;
  cout << "Part 2" << endl;
  cout << endl;

  
  Relation courseRelation("courses", Scheme( {"ID", "Course"} ));

  vector<string> courseValues[] = {
    {"'42'", "'CS 100'"},
    {"'32'", "'CS 232'"},
  };

  for (auto& value : courseValues)
    courseRelation.addTuple(Tuple(value));
  
  studentRelation.join(courseRelation);

}

// int main() {

//   vector<string> names = { "ID", "Name", "Major" };

//   Scheme scheme(names);

//   Relation relation("student", scheme);

//   vector<string> values[] = {
//     {"'42'", "'Ann'", "'CS'"},
//     {"'32'", "'Bob'", "'CS'"},
//     {"'64'", "'Ned'", "'EE'"},
//     {"'16'", "'Jim'", "'EE'"},
//   };

//   for (auto& value : values) {
//     Tuple tuple(value);
//     cout << tuple.toString(scheme) << endl;
//     relation.addTuple(tuple);
//   }

//   cout << "relation:" << endl;
//   cout << relation.toString();

//   Relation result = relation.rename(0, "Testing");

//   cout << "select Major='CS' result:" << endl;
//   cout << result.toString();

// }
