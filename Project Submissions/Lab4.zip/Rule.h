#include <vector>
#include "Predicate.h"
#include <iostream>
#include <sstream>
using namespace std;
#pragma once
class Rule {
    private:
        Predicate head;
        vector<Predicate> body;
    public:
        Rule(const Predicate& headParam, const vector<Predicate>& bodyParam) : head(headParam), body(bodyParam) {}

    string toString() const {
        stringstream out;
        out << head.toString() << " :- " << body.at(0).toString();
        for(int i = 1; i < body.size(); i++){
            out << "," << body.at(i).toString();
        }
        out << ".";
        return out.str();
    }
};