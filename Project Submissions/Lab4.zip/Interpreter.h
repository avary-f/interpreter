#include <vector>
#include <string>
using namespace std;
#pragma once
#include "Database.h"
#include "Relation.h"
#include "DatalogProgram.h"
#include <iostream>
#include <unordered_map>

class Interpreter {

private:
    Database database;
    DatalogProgram program;

public:
    Interpreter(const DatalogProgram& program) : program(program) {}

void evalSchemes(){
    for(int i = 0; i < program.getSchemes().size(); i++){
        string name = program.getSchemes().at(i).getID();
        vector<string> attributes = program.getSchemes().at(i).getParameters();
        database.addRelation(name, Relation(name, attributes));
    }
}

void evalFacts(){
    for(int i = 0; i < program.getFacts().size(); i++){
        string name = program.getFacts().at(i).getID();
        vector<string> values = program.getFacts().at(i).getParameters();
        database.addTupletoRelation(name, Tuple(values));
    }
}

void evalQueries() {
    for (int i = 0; i < program.getQueries().size(); i++) {
        string name = program.getQueries().at(i).getID();
        Relation relation = Relation(name, database.getRelationTuples(name));
        map<string, int> variables;
        vector<string> orderOfAppearance;  // Keep track of the order of appearance

        for (int j = 0; j < program.getQueries().at(i).getParameters().size(); j++) {
            string param_name = program.getQueries().at(i).getParameters().at(j);

            if (param_name[0] == '\'') {
                relation = relation.select(j, param_name);
            } else {
                auto var = variables.find(param_name);
                if (var == variables.end()) {
                    variables[param_name] = j;
                    orderOfAppearance.push_back(param_name);  // Record the order
                } else {
                    relation = relation.select2(var->second, j);
                }
            }
        }

        vector<int> indexes;  // Indexes of variables
        for (const auto& variable : orderOfAppearance) {
            indexes.push_back(variables[variable]);
        }

        // Testing
        // cout << "Variables order of appearance: ";
        // for (const auto& element : orderOfAppearance) {
        //     cout << element << " ";
        // }
        // cout << endl;

        // Project and rename
        relation = relation.project(indexes);
        relation = relation.rename(indexes, orderOfAppearance);

        string result;
        if (relation.sizeTuples() != 0) {
            result = "Yes(" + to_string(relation.sizeTuples()) + ")";
        } else {
            result = "No";
        }

        cout << program.getQueries().at(i).toString() << "? ";
        cout << result << endl;

        if (variables.size() != 0) {
            cout << relation.toString();
        }
    }
}
};