#include <vector>
#include <string>
using namespace std;
#pragma once
#include "Scheme.h"
#include "Tuple.h"
#include <set> // needed to include set class
#include <iostream>

class Relation {

private:
    string name;
    Scheme scheme;
    set<Tuple> tuples;

public:
    Relation(const string name, const Scheme& scheme) : name(name), scheme(scheme) {} //constructor
    Relation(const string name, const set<Tuple>& tuples) : name(name), tuples(tuples), scheme(initializeScheme(tuples)){}
    Relation(){}

    Scheme initializeScheme(const set<Tuple>& tuples) {
        if (!tuples.empty()) {
            vector<string> schemes = (*tuples.begin()).getValues();
            return Scheme(schemes);
        }
        // Handle the case when tuples is empty
        return Scheme(); 
    }

void addTuple(const Tuple& tuple) {
    tuples.insert(tuple); //use insert to add to a set
}
set<Tuple> getTuples() {
    return tuples;
}

Scheme getScheme() {
    return scheme;
}

int sizeTuples() const{
    return tuples.size();
}

void setScheme(Scheme s){
    scheme = s;
}

void setName(string n){
    name = n;
}

string toString() const {
    string str;
    if (tuples.empty()) {
        return "";
    }
    auto current = tuples.begin(); // will be an iterator pointing to the first element of tuples set
    //str = current->toString(scheme); // the -> is used to dereference the current object
    for (int i = 0; i < tuples.size(); i++) { // use ++current in the loop header
        str = str + "  " + current->toString(scheme) + "\n";
        current++;
    }
    return str;
}

Relation select2(int index, int index2) const { //compares two indexes
    Relation rel(name, scheme);
    auto current = tuples.begin();
    for(int i = 0; i < tuples.size(); i++){
        if(current->at(index) == current->at(index2)){
            rel.addTuple(*current);
        }
        current++;
    }
    return rel;
}

Relation select(int index, const string& value) const { //compares index and passed value
    Relation rel(name, scheme);
    auto current = tuples.begin();
    for(int i = 0; i < tuples.size(); i++){
        if(current->at(index) == value){
            rel.addTuple(*current);
        }
        current++;
    }
    return rel;
}

Relation rename(vector<int> indexes, vector<string> newNames) const {
    //vector<string> newNames;
    // for(int i = 0; i < scheme.size(); i++){
    //     if(i == index) {
    //         newNames.push_back(newName);
    //     }
    //     else{
    //         newNames.push_back(scheme.at(i));
    //     }
    // }
    Scheme newScheme(newNames);
    Relation rel(name, newScheme);
    auto current = tuples.begin();
    for(int i = 0; i < tuples.size(); i++){
        rel.addTuple(*current);
        current++;
    }
    //Testing
    //cout << "New Name: " << newName << endl;
    // for(auto const& element : newNames) {
    //     cout << element << " ";
    // }
    // cout << endl;
    //Testing Complete
    
    return rel;
}

Relation project(vector<int> indexes) const { //this will need to be able to change the column order in the next proj
    //Create new scheme with correct columns
    vector<string> newSchemeList;
    for(int i = 0; i < scheme.size(); i++){
        for(int j = 0; j < indexes.size(); j++){ //loops through the bad indexes
            if(i == indexes.at(j)){
                newSchemeList.push_back(scheme.at(i));
            }
        }
    }
    Scheme newScheme(newSchemeList);
 
    //Create new relation
    Relation rel(name, newScheme); //uses current scheme name & adds new Scheme list

    //Add tuples to relation
    auto current = tuples.begin();
    vector<string> newValues;
    for(const auto&element : tuples) { //iterate through each tuple
        for(int i = 0; i < current->size(); i++){ //loops through the current's value indexes
            for(int j = 0; j < indexes.size(); j++){ //loops through the bad indexes
                if(i == indexes.at(j)){
                    newValues.push_back(current->at(i));
                }
            }
        }
        Tuple n(newValues);
        rel.addTuple(n);
        newValues = {};
        current++;
    }
    return rel;
}

static bool joinable(const Scheme& leftScheme, const Scheme& rightScheme, const Tuple& leftTuple, const Tuple& rightTuple) {
    for (unsigned leftIndex = 0; leftIndex < leftScheme.size(); leftIndex++) {
        const string& leftName = leftScheme.at(leftIndex);
        const string& leftValue = leftTuple.at(leftIndex);
        cout << "left name: " << leftName << " value: " << leftValue << endl;
        for (unsigned rightIndex = 0; rightIndex < rightScheme.size(); rightIndex++) {
            const string& rightName = rightScheme.at(rightIndex);
            const string& rightValue = rightTuple.at(rightIndex);
            if(rightName == leftName){
                if(rightValue != leftValue)
                    return false;
            }
            cout << "right name: " << rightName << " value: " << rightValue << endl;
        }
    }
    return true;
}

Relation join(const Relation& right) {
    const Relation& left = *this;
    Relation result;
    auto thisTupL = left.tuples.begin();
    for(unsigned leftIndex = 0; leftIndex < left.tuples.size(); leftIndex++){
        advance(thisTupL, leftIndex);
        cout << "left tuple: " << thisTupL->toString(left.scheme) << endl;
        auto thisTupR = right.tuples.begin();
        for(unsigned rightIndex = 0; rightIndex < right.tuples.size(); rightIndex++){
            advance(thisTupR, rightIndex);
            cout << "right tuple: " << thisTupR->toString(right.scheme) << endl;
        }
    }
    return result;
}

};
