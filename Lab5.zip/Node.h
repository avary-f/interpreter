#include <vector>
#include <string>
using namespace std;
#pragma once
#include <set> // needed to include set class
#include <iostream>

class Node {

 private:

  set<int> adjacentNodeIDs;

 public:

  Node() {}

  void addEdge(int adjacentNodeID) {
    adjacentNodeIDs.insert(adjacentNodeID);
  }

  string toString() {
    string s;
    int count = 0;
    int size = adjacentNodeIDs.size();
    for (int index : adjacentNodeIDs) {
        if (size - 1 == count) {
            s += "R" + to_string(index);
        } else {
            s += "R" + to_string(index) + ",";
        }
        count++;
    }
    return s; // Add this line to return the constructed string
}


};