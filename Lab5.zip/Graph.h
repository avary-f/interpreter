#include <vector>
#include <string>
using namespace std;
#pragma once
#include <set> // needed to include set class
#include <iostream>
#include "Node.h"
#include <map> 

class Graph {

 private:

  map<int,Node> nodes;

 public:

  Graph(int size) {
    for (int nodeID = 0; nodeID < size; nodeID++)
      nodes[nodeID] = Node();
  }

  void addEdge(int fromNodeID, int toNodeID) {
    nodes[fromNodeID].addEdge(toNodeID);
  }

  string toString(){
    string s;
    for (auto& pair: nodes) {
      int nodeID = pair.first;
      Node node = pair.second;
      s = s + "R" + to_string(nodeID) + ":" + node.toString() + "\n";
    }
    return s;
  }

};